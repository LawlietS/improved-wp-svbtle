<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>

	<title>svbtle dashboard | <?php bloginfo('name'); ?></title>
	
	<script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
	<script src="js/jquery.textarea-expander.js" type="text/javascript" charset="utf-8"></script>
	<script src="script.js?v=<?php echo filemtime(realpath(dirname(__FILE__)).'/../script.js'); ?>" type="text/javascript" charset="utf-8"></script>
	
	<link rel="stylesheet" href="style.css?v=<?php echo filemtime(realpath(dirname(__FILE__)).'/../style.css'); ?>" type="text/css" media="screen" title="no title" charset="utf-8">
	
</head>

<body class="page-<?php echo $page ?>">
	

